//File: townwize-frontend\src\pages\passenger\Booking\SelectRide.jsx
/* global google */
import React from "react";
import { useState, useEffect, useCallback, useMemo, } from "react";
import LocationField from "../../../components/passenger/LocationField";
import PassengerLayout from "../../../layouts/PassengerLayout";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import useMapCore from "./hooks/useMapCore";
import useMarkers from "./hooks/useMarkers";
import useRouteEngine from "./hooks/useRouteEngine";
// Components- pages\passenger\Booking\components
import RouteLoaderOverlay from "./components/RouteLoaderOverlay";
import MapSelectionOverlay from "./components/MapSelectionOverlay";
import RideTypeCard from "./components/RideTypeCard";

//import { memo } from "react";
import {
  FaMapMarkerAlt,
  FaRoute,
  FaCarSide,
  FaUsers,
  FaClock,
  FaPlus,
  FaTimes,
  FaDotCircle,
  FaCrosshairs,
} from "react-icons/fa";

// 🧩 Auth Context
import { useContext } from "react";
import AuthContext from "../../../contexts/AuthContext";

const SelectRide = () => {
  const navigate = useNavigate();
  // ✅ Step 5: Restore persisted ride state early (before useLocation clears)
  const lastRideState = JSON.parse(sessionStorage.getItem("selectRideStatePersist") || "{}");
  const { state: routeStateRaw } = useLocation();
  const state = routeStateRaw && Object.keys(routeStateRaw).length ? routeStateRaw : lastRideState;

  //const { state } = useLocation();

  // ✅ Step 1: Keep a copy of state so it survives reloads or login redirects
  useEffect(() => {
    if (state?.pickup && state?.dropoff) {
      sessionStorage.setItem("selectRideStatePersist", JSON.stringify(state));
    }
  }, [state]);

  // ✅ Step 2: Load the saved state if current state is missing (after login redirect)
  const persistedState = JSON.parse(sessionStorage.getItem("selectRideStatePersist") || "{}");
  const effectiveState = state && Object.keys(state).length ? state : persistedState;


  // Auth Context
  const { user, loading } = useContext(AuthContext);
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Close modal on login
  useEffect(() => {
    if (user) setShowAuthModal(false);
  }, [user]);

  // 🔓 Forcefully re-enable UI once authenticated
  useEffect(() => {
    if (user && !showAuthModal) {
      document.body.style.pointerEvents = "auto";
    }
  }, [user, showAuthModal]);

  // Redirect to home if no pickup/dropoff in state or sessionStorage
  // ✅ Auth gate runs AFTER map hooks mount
  useEffect(() => {
    if (loading) return;

    // Wait until map hooks are ready
    const timer = setTimeout(() => {
      if (!user) setShowAuthModal(true);
    }, 300);

    return () => clearTimeout(timer);
  }, [user, loading]);



  // restore from sessionStorage on refresh
  const persisted = JSON.parse(sessionStorage.getItem("selectRideState") || "{}");
  const [pickup, setPickup] = useState(state?.pickup || persisted.pickup || "");
  const [dropoff, setDropoff] = useState(state?.dropoff || persisted.dropoff || "");
  // restore stops from sessionStorage on refresh - conditional
  const comingFromHome = !!(state?.pickup && state?.dropoff);
  const [stop, setStop] = useState(
    comingFromHome ? "" : state?.stop || persisted.stop || ""
  );
  const [hasStop, setHasStop] = useState(
    comingFromHome ? false : state?.stop ? true : persisted.hasStop || false
  );

  useEffect(() => {
    sessionStorage.setItem(
      "selectRideState",
      JSON.stringify({
        pickup,
        stop,
        dropoff,
        hasStop,
      })
    );
  }, [pickup, stop, dropoff, hasStop]);

  const [selectedType, setSelectedType] = useState(null);
  const [fare, setFare] = useState(0);
  const [eta, setEta] = useState("");
  const [selectingFor, setSelectingFor] = useState(null);
  // Multiple Route Choice States
  //const [selectedRouteIndex, setSelectedRouteIndex] = useState(0);

  window.__setPickup = setPickup;
  window.__setStop = setStop;
  window.__setDropoff = setDropoff;

  // --- NEW HOOKS: Map Core ---
  const {
    mapRef: coreMapRef,
    mapInstanceRef: coreMapInstanceRef,
    mapsReadyRef: coreMapsReadyRef,
    sessionTokenRef: coreSessionTokenRef,
  } = useMapCore({
    onMapClick: (latLng) => {
      let target = selectingFor;
      // Intelligent auto-target:
      if (!target) {
        if (!pickup) target = "pickup";
        else if (!dropoff) target = "dropoff";
        else return; // both exist → require explicit selection
      }
      if (coreMapsReadyRef.current && coreMapInstanceRef.current) {
        updateMapMarker(latLng, target);
      } else {
        console.warn("Map not ready → marker skipped");
      }
      reverseGeocode(latLng, (addr) => {
        if (target === "pickup") setPickup(addr);
        if (target === "stop") setStop(addr);
        if (target === "dropoff") setDropoff(addr);
      });
      setSelectingFor(null);
    },
  });

  const getGeocoder = async () => {
    const { Geocoder } = await google.maps.importLibrary("geocoding");
    return new Geocoder();
  };
  // Reverse geocode coordinates to address
  const reverseGeocode = useCallback(async (latLng, setter) => {
    if (!window.google?.maps) return;
    const geocoder = await getGeocoder();
    geocoder.geocode({ location: latLng }, (results, status) => {
      if (status === "OK" && results?.[0]) {
        setter(results[0].formatted_address);
      }
    });
  }, []);
  // --- NEW HOOKS: Markers ---
  const {
    pickupMarkerRef,
    stopMarkerRef,
    dropoffMarkerRef,
    updateMapMarker,
  } = useMarkers({
    mapInstanceRef: coreMapInstanceRef,
    reverseGeocode,
  });

  // --- NEW HOOKS: Route Engine ---
  const { requestRoute, isCalculatingRoute, etaText, distanceKm } = useRouteEngine({
    mapInstanceRef: coreMapInstanceRef,
    pickupMarkerRef,
    stopMarkerRef,
    dropoffMarkerRef,
  });
  // Route readiness check
  const routeReady = distanceKm > 0 && etaText;
  // Suggestions
  const [pickupSuggestions, setPickupSuggestions] = useState([]);
  const [stopSuggestions, setStopSuggestions] = useState([]);
  const [dropoffSuggestions, setDropoffSuggestions] = useState([]);
  // Searching state
  const [searching, setSearching] = useState(false);
  // Fare calculation
  useEffect(() => {
    if (!selectedType) return;
    // Calculate fare based on distance (real)
    if (distanceKm > 0) {
      const baseFare = selectedType === "Private Ride" ? 100 : 70;
      const perKmRate = selectedType === "Private Ride" ? 30 : 20;
      setFare(Math.round(baseFare * 1 + perKmRate * distanceKm));
    }
  }, [selectedType, distanceKm]);
  // ETA stays perfectly stable
  useEffect(() => {
    setEta(etaText || "");
  }, [etaText]);
  // Fetch place suggestions
  const fetchSuggestions = useCallback(async (input, setter) => {
    if (!coreMapsReadyRef.current || !input) {
      setter([]);
      return;
    }
    try {
      const service = new google.maps.places.AutocompleteService();
      const result = await service.getPlacePredictions({
        input,
        sessionToken: coreSessionTokenRef.current,
        componentRestrictions: { country: "pk" },
      });
      setter(result.predictions.map(p => ({
        description: p.description,
        placeId: p.place_id,
        text: p.structured_formatting.main_text,
      })));
    } catch (err) {
      console.error("Suggestions failed:", err);
      setter([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // Handle GPS location
  const handleGPS = useCallback((setter, type) => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser.");
      return;
    }
    toast.info("Fetching your location...");
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        console.log("REFINED GPS (SelectRide):", latitude, longitude, "accuracy:", accuracy);
        // Wait for a reasonably accurate fix
        if (accuracy <= 50) {
          navigator.geolocation.clearWatch(watchId);
          if (coreMapsReadyRef.current && coreMapInstanceRef.current) {
            updateMapMarker({ lat: latitude, lng: longitude }, type);
          }
          reverseGeocode({ lat: latitude, lng: longitude }, setter);
        }
      },
      (err) => {
        console.error("Geolocation error:", err);
        toast.error("Unable to fetch location.");
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 10000,
      }
    );
  }, [reverseGeocode, updateMapMarker, coreMapInstanceRef, coreMapsReadyRef]);
  // Continue to trip summary
  const handleContinue = () => {
    if (!pickup.trim() || !dropoff.trim()) {
      toast.error("Please set both pickup and dropoff");
      return;
    }
    if (!selectedType) {
      toast.error("Please select a ride type");
      return;
    }
    setSearching(true);
    setTimeout(() => {
      // clear persisted SelectRide state on successful completion
      sessionStorage.removeItem("selectRideState");

      console.log("🚕 FINAL TRIP PAYLOAD", {
  pickup,
  dropoff,
  pickupCoords: pickupMarkerRef.current?.position?.toJSON?.(),
  dropoffCoords: dropoffMarkerRef.current?.position?.toJSON?.(),
  distanceKm,
  etaMinutes: Math.round((distanceKm / 30) * 60),
  fare,
});

// helper to normalise marker positions
const getLatLng = (pos) => {
  if (!pos) return null;
  return typeof pos.lat === "function"
    ? { lat: pos.lat(), lng: pos.lng() }
    : { lat: pos.lat, lng: pos.lng };
};

const pickupCoords = pickupMarkerRef.current
  ? getLatLng(pickupMarkerRef.current.position)
  : null;

const dropoffCoords = dropoffMarkerRef.current
  ? getLatLng(dropoffMarkerRef.current.position)
  : null;

navigate("/passenger/trip-summary", {
  replace: true,
  state: {
    pickup,
    stop: hasStop ? stop : null,
    dropoff,

    // ✅ REQUIRED COORDINATES
    pickupCoords,
    dropoffCoords,

    // ✅ REQUIRED NUMBERS
    distanceKm, // number
    etaMinutes: Math.round(
      distanceKm > 0 ? (distanceKm / 30) * 60 : 0
    ),

    // display values
    eta,
    rideType: selectedType,
    fare,
  },
});

    }, 800);
    // short delay to show success state
  };

  const pickupProps = useMemo(() => ({
    label: "Pickup Location",
    value: pickup,
    onChange: setPickup,
    onClear: () => setPickup(""),
    onGPS: () => handleGPS(setPickup, "pickup"),
    onMap: () => setSelectingFor("pickup"),
    suggestions: pickupSuggestions,
    setSuggestions: setPickupSuggestions,
    onSelect: (p) => {
      const placesService = new google.maps.places.PlacesService(coreMapInstanceRef.current);
      placesService.getDetails(
        { placeId: p.placeId, fields: ["formatted_address", "geometry"] },
        (place, status) => {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            setPickup(place.formatted_address);
            if (coreMapsReadyRef.current && coreMapInstanceRef.current) {
              updateMapMarker(place.geometry.location, "pickup");
            } else {
              console.warn("Map not ready → pickup marker skipped");
            }
          }
        }
      );
      setPickupSuggestions([]);
    },
    icon: <FaMapMarkerAlt className="text-townwize-primary dark:text-townwize-textContent text-lg mr-3" />,
  }), [pickup, pickupSuggestions, handleGPS, updateMapMarker, coreMapInstanceRef, coreMapsReadyRef]);

  const stopProps = useMemo(() => ({
    label: "Stop",
    value: stop,
    onChange: setStop,
    onClear: () => setStop(""),
    onGPS: () => handleGPS(setStop, "stop"),
    onMap: () => setSelectingFor("stop"),
    suggestions: stopSuggestions,
    setSuggestions: setStopSuggestions,
    onSelect: (p) => {
      const placesService = new google.maps.places.PlacesService(coreMapInstanceRef.current);
      placesService.getDetails(
        { placeId: p.placeId, fields: ["formatted_address", "geometry"] },
        (place, status) => {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            setStop(place.formatted_address);
            if (coreMapsReadyRef.current && coreMapInstanceRef.current) {
              updateMapMarker(place.geometry.location, "stop");
            } else {
              console.warn("Map not ready → stop marker skipped");
            }

          }
        }
      );
      setStopSuggestions([]);
    },
    icon: <FaDotCircle className="text-blue-500 text-lg mr-3" />,
  }), [stop, stopSuggestions, handleGPS, updateMapMarker, coreMapInstanceRef, coreMapsReadyRef]);

  const dropoffProps = useMemo(() => ({
    label: "Dropoff Location",
    value: dropoff,
    onChange: setDropoff,
    onClear: () => setDropoff(""),
    onGPS: () => handleGPS(setDropoff, "dropoff"),
    onMap: () => setSelectingFor("dropoff"),
    suggestions: dropoffSuggestions,
    setSuggestions: setDropoffSuggestions,
    onSelect: (p) => {
      const placesService = new google.maps.places.PlacesService(coreMapInstanceRef.current);
      placesService.getDetails(
        { placeId: p.placeId, fields: ["formatted_address", "geometry"] },
        (place, status) => {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            setDropoff(place.formatted_address);
            if (coreMapsReadyRef.current && coreMapInstanceRef.current) {
              updateMapMarker(place.geometry.location, "dropoff");
            } else {
              console.warn("Map not ready → dropoff marker skipped");
            }
          }
        }
      );
      setDropoffSuggestions([]);
    },
    icon: <FaRoute className="text-red-500 text-lg mr-3" />,
  }), [dropoff, dropoffSuggestions, handleGPS, updateMapMarker, coreMapInstanceRef, coreMapsReadyRef]);


  // --- DEBUG: Verify navigation + map readiness ---
  useEffect(() => {
    console.log("🧭 SelectRide debug snapshot:", {
      state,
      mapReady: coreMapsReadyRef.current,
      hasMapInstance: !!coreMapInstanceRef.current,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, coreMapsReadyRef.current]);

  // === Restore original behavior: Auto-place markers if coming from previous screen ===
  useEffect(() => {
    let checkTimer;

    const tryRestore = async () => {
      if (!coreMapsReadyRef.current || !coreMapInstanceRef.current) {
        // keep polling until map is truly ready
        checkTimer = setTimeout(tryRestore, 200);
        return;
      }

      if (!effectiveState?.pickup || !effectiveState?.dropoff) return;

      console.log("🧭 ✅ Running delayed restore once map ready");

      const geocoder = await getGeocoder();

      geocoder.geocode({ address: effectiveState.pickup }, (results, status) => {
        if (status === "OK" && results?.[0]?.geometry?.location) {
          updateMapMarker(results[0].geometry.location, "pickup");
          setPickup(results[0].formatted_address);
        }
      });

      geocoder.geocode({ address: effectiveState.dropoff }, (results, status) => {
        if (status === "OK" && results?.[0]?.geometry?.location) {
          updateMapMarker(results[0].geometry.location, "dropoff");
          setDropoff(results[0].formatted_address);
        }
      });
    };

    tryRestore();
    return () => clearTimeout(checkTimer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveState, pickup, stop, dropoff]);

  // 🧭 Auto-draw route when markers change
  useEffect(() => {
    if (!pickupMarkerRef.current || !dropoffMarkerRef.current) return;
    requestRoute();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pickup, stop, dropoff]);

  // ✅ Step 7: Always re-trigger marker restore once the map is fully ready
  useEffect(() => {
    if (!coreMapsReadyRef.current || !coreMapInstanceRef.current) return;
    if (!effectiveState?.pickup || !effectiveState?.dropoff) return;

    console.log("🧭 Forced restore fired after map ready");

    (async () => {
      const geocoder = await getGeocoder();

      geocoder.geocode({ address: effectiveState.pickup }, (results, status) => {
        if (status === "OK" && results?.[0]?.geometry?.location) {
          updateMapMarker(results[0].geometry.location, "pickup");
          setPickup(results[0].formatted_address);
        }
      });

      geocoder.geocode({ address: effectiveState.dropoff }, (results, status) => {
        if (status === "OK" && results?.[0]?.geometry?.location) {
          updateMapMarker(results[0].geometry.location, "dropoff");
          setDropoff(results[0].formatted_address);
        }
      });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coreMapsReadyRef.current, coreMapInstanceRef.current, effectiveState]);

  return (
    <>
      <div
        className={`grid grid-cols-1 md:grid-cols-[420px_1fr] gap-6 items-start mb-6 ${!user && showAuthModal ? "blur-sm pointer-events-none select-none" : ""
          }`}
        onClick={() => {
          setPickupSuggestions([]);
          setDropoffSuggestions([]);
          setStopSuggestions([]);
        }}
      >

        {/* Left Panel - Form */}
        <div className="bg-white dark:bg-townwize-primaryDark shadow-xl rounded-2xl px-5 py-6 space-y-5 w-full md:max-w-[420px] mx-auto md:mx-0">
          {/* Pickup */}
          <div onClick={(e) => e.stopPropagation()}>
            <LocationField {...pickupProps} fetchSuggestions={fetchSuggestions} />
          </div>

          {/* Stop */}
          {hasStop ? (
            <div className="space-y-3 animate-fadeIn">
              <div onClick={(e) => e.stopPropagation()}>
                <LocationField
                  {...stopProps}
                  fetchSuggestions={fetchSuggestions}
                  className="stop-field"
                />
              </div>

              <button
                type="button"
                onClick={() => setHasStop(false)}
                className="text-red-500 text-xs flex items-center gap-1 hover:underline"
              >
                <FaTimes /> Remove stop
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setHasStop(true);
              }}
              className="text-townwize-primary dark:text-townwize-textContent text-sm flex items-center gap-1"
            >
              <FaPlus /> Add stop
            </button>
          )}

          {/* Dropoff */}
          <div onClick={(e) => e.stopPropagation()}>
            <LocationField {...dropoffProps} fetchSuggestions={fetchSuggestions} />
          </div>

          {/* Ride type cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <RideTypeCard
              title="Private Ride"
              icon={<FaCarSide />}
              selected={selectedType === "Private Ride"}
              disabled={!routeReady}
              onSelect={() => routeReady && setSelectedType("Private Ride")}
            >
              {/* Fare + ETA */}
              <span>
                {distanceKm > 0 ? (
                  `${fare} PKR`
                ) : (
                  <span className="inline-block tw-shimmer h-4 w-14 rounded-md"></span>
                )}
                • <FaClock className="inline" />{" "}
                {isCalculatingRoute ? (
                  <span className="inline-block tw-shimmer h-4 w-12 rounded-md"></span>
                ) : (
                  etaText || "—"
                )}
              </span>

              {/* Distance */}
              <div className="text-xs text-gray-200 dark:text-gray-300 mt-1">
                {isCalculatingRoute ? (
                  <span className="inline-block tw-shimmer h-3 w-10 rounded-md"></span>
                ) : distanceKm > 0 ? (
                  `${distanceKm.toFixed(1)} km`
                ) : (
                  "—"
                )}
              </div>
            </RideTypeCard>

            <RideTypeCard
              title="RideTogether"
              icon={<FaUsers />}
              selected={selectedType === "RideTogether"}
              disabled={!routeReady}
              onSelect={() => routeReady && setSelectedType("RideTogether")}
            >
              {/* Fare + ETA */}
              <span>
                {distanceKm > 0 ? (
                  `${fare} PKR`
                ) : (
                  <span className="inline-block tw-shimmer h-4 w-14 rounded-md"></span>
                )}
                • <FaClock className="inline" />{" "}
                {isCalculatingRoute ? (
                  <span className="inline-block tw-shimmer h-4 w-12 rounded-md"></span>
                ) : (
                  etaText || "—"
                )}
              </span>

              {/* Distance */}
              <div className="text-xs text-gray-200 dark:text-gray-300 mt-1">
                {isCalculatingRoute ? (
                  <span className="inline-block tw-shimmer h-3 w-10 rounded-md"></span>
                ) : distanceKm > 0 ? (
                  `${distanceKm.toFixed(1)} km`
                ) : (
                  "—"
                )}
              </div>
            </RideTypeCard>

          </div>

          {/* Search Button */}
          <div className="relative w-full mt-5">
            <button
              onClick={handleContinue}
              disabled={!pickup || !dropoff || !selectedType || !routeReady}
              className={`w-full py-3 rounded-xl font-semibold overflow-hidden shadow-md relative ${pickup && dropoff && selectedType
                ? "text-white"
                : "bg-gray-100 text-gray-400 cursor-not-allowed opacity-60"
                }`}
            >
              {/* Animated fill when searching */}
              {pickup && dropoff && selectedType && (
                <span
                  className={`absolute inset-0 rounded-xl transition-all duration-500 ease-in-out ${searching
                    ? "bg-gradient-to-r from-townwize-primary to-townwize-primaryDark animate-[pulse_1.2s_ease-in-out_infinite]"
                    : "bg-townwize-primary hover:bg-townwize-primaryDark"
                    }`}
                ></span>
              )}

              <span className="relative z-10">
                {searching ? "Preparing Summary..." : "Search"}
              </span>
            </button>
          </div>
        </div>

        {/* Right Panel - Map */}
        <div className="w-full h-[calc(100vh-160px)] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden relative">
          <div ref={coreMapRef} className="w-full h-full" />


          {/* STEP 3.2 — Route Calculating Overlay */}
          <RouteLoaderOverlay isVisible={isCalculatingRoute} />

          <MapSelectionOverlay
            selectingFor={selectingFor}
            onCancel={() => setSelectingFor(null)}
          />

        </div>
      </div>
      {/* --- AUTH GATE MODAL --- */}
      {showAuthModal && (
        <div className="fixed inset-0  flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl text-center w-[90%] max-w-sm">
            <h2 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white">
              Log in to view and choose the desired ride options
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Please sign in to continue your booking.
            </p>

            <div className="flex justify-center gap-4">

              <button
                onClick={() =>
                  navigate("/login", {
                    state: {
                      from: "/passenger/select-ride",
                      pickup: pickup || "",
                      dropoff: dropoff || "",
                      pickupCoords: pickupMarkerRef.current
                        ? pickupMarkerRef.current.position
                        : null,
                    },
                  })
                }
                className="px-4 py-2 rounded-lg bg-townwize-primary text-white hover:opacity-90"
              >
                Login
              </button>


              <button
                onClick={() => (window.location.href = "/register")}
                className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:opacity-90"
              >
                Register
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );

};
export default SelectRide;
