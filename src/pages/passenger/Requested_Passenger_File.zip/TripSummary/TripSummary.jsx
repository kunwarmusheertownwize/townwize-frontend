// File: townwize-frontend\src\pages\passenger\TripSummary\TripSummary.jsx

import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { getSocket } from "../../../hooks/useRideSocket";


const TripSummary = () => {
  const { state } = useLocation();
  console.log("TripSummary state:", state);

  const navigate = useNavigate();
  //const socket = useRideSocket();

  const [confirming, setConfirming] = useState(false);

  // Basic required text fields
  const pickup = state?.pickup || "";
  const dropoff = state?.dropoff || "";
  const rideType = state?.rideType || null;
  const fare = state?.fare ?? 0;

  // REQUIRED backend fields (DO NOT DROP)
  const pickupCoords = state?.pickupCoords;
  const dropoffCoords = state?.dropoffCoords;
  const distanceKm = state?.distanceKm;
  const etaMinutes = state?.etaMinutes;

  // Display-only ETA string (optional)
  const etaLabel = state?.eta || "";

  // Hard guard — redirect immediately if state is broken
  useEffect(() => {
    if (
      !pickup ||
      !dropoff ||
      !rideType ||
      fare == null ||
      !pickupCoords ||
      !dropoffCoords ||
      typeof distanceKm !== "number" ||
      typeof etaMinutes !== "number"
    ) {
      //toast.error("Trip data expired. Please reselect your ride.");
      navigate("/passenger/select-ride", { replace: true });
    }
  }, [
    pickup,
    dropoff,
    rideType,
    fare,
    pickupCoords,
    dropoffCoords,
    distanceKm,
    etaMinutes,
    navigate,
  ]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;

    const onRideAccepted = (payload) => {
      console.log("✅ Passenger received ride:accepted", payload);

      navigate("/passenger/trip", {
        replace: true,
        state: payload,
      });
    };

    socket.on("ride:accepted", onRideAccepted);

    return () => {
      socket.off("ride:accepted", onRideAccepted);
    };
  }, [navigate]);

  if (!rideType) return null;

  return (
    <div className="max-w-2xl mx-auto bg-white dark:bg-townwize-primaryDark p-8 rounded-2xl shadow-lg space-y-6 text-townwize-textPrimary dark:text-white mt-6">
      {/* Header */}
      <h2 className="text-2xl font-bold text-townwize-primary dark:text-townwize-accent">
        Trip Summary
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400">
        Review your trip details before confirming.
      </p>

      {/* Details */}
      <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-xl space-y-2 border border-gray-200 dark:border-gray-700">
        <p><strong>Pickup:</strong> {pickup}</p>
        <p><strong>Dropoff:</strong> {dropoff}</p>
        <p><strong>Ride Type:</strong> {rideType}</p>
        <p><strong>ETA:</strong> {etaLabel}</p>
        <p><strong>Estimated Fare:</strong> {fare} PKR</p>
      </div>

      {/* Confirm Button */}
      <div className="relative">
        <button
          disabled={confirming}
          onClick={() => {
            setConfirming(true);
            setTimeout(() => {
              navigate("/passenger/trip-request", {
                state: {
                  pickup,
                  dropoff,
                  pickupCoords,
                  dropoffCoords,
                  distanceKm,
                  etaMinutes,
                  rideType,
                  fare,
                },
              });

            }, 600);
          }}
          className={`w-full py-3 rounded-xl font-semibold transition-all duration-300 shadow-md ${confirming
            ? "cursor-wait text-white bg-townwize-primaryDark"
            : "text-white bg-townwize-primary hover:bg-townwize-primaryDark"
            }`}
        >
          {confirming ? "Confirming..." : "Confirm Trip"}
        </button>
      </div>

      {/* Cancel */}
      <button
        onClick={() => navigate(-1)}
        className="w-full py-3 rounded-xl font-semibold bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition"
      >
        Cancel
      </button>
    </div>
  );
};

export default TripSummary;