/* global google */
import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import api from "../../../services/api";
import { useRideSocket } from "../../../hooks/useRideSocket";
import { useParams } from "react-router-dom";

const LiveTracking = () => {
  const { rideId } = useParams();
  const { state } = useLocation();
  //const navigate = useNavigate();

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const driverMarkerRef = useRef(null);
  const routeRendererRef = useRef(null);

  const [ride, setRide] = useState(null);

  // ─────────────────────────────────────────────
  // ❌ HARD STOP if no rideId
  // ─────────────────────────────────────────────
  /*  useEffect(() => {
     if (!state?.rideId) {
       navigate("/", { replace: true });
     }
   }, [state, navigate]); */

  // ─────────────────────────────────────────────
  // Fetch active ride (authoritative backend state)
  // ─────────────────────────────────────────────
  useEffect(() => {
    if (!rideId) return;

    let cancelled = false;

    api
      .get(`/rides/${rideId}`)
      .then((res) => {
        if (!cancelled && res?.data?.data) {
          setRide(res.data.data);
        }
      })
      .catch((err) => {
        if (err?.response?.status === 401) {
          // 🔒 stop silently – interceptor will handle redirect
          return;
        }
      });

    return () => {
      cancelled = true;
    };
  }, [rideId]);


  // ─────────────────────────────────────────────
  // Socket updates (status + driver position)
  // ─────────────────────────────────────────────
  useRideSocket(state?.rideId, (payload) => {
    setRide((prev) => {
      if (!prev) return prev;
      return { ...prev, ...payload };
    });
  });

  // ─────────────────────────────────────────────
  // Initialize map ONCE (pickup-centered)
  // ─────────────────────────────────────────────
  useEffect(() => {
    if (!ride || mapInstanceRef.current || !window.google?.maps) return;

    const pickupLatLng = {
      lat: ride.pickup.lat,
      lng: ride.pickup.lng,
    };

    const map = new google.maps.Map(mapRef.current, {
      center: pickupLatLng,
      zoom: 15,
      disableDefaultUI: true,
    });

    mapInstanceRef.current = map;

    // Pickup marker
    new google.maps.Marker({
      position: pickupLatLng,
      map,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 7,
        fillColor: "#6CBEED",
        fillOpacity: 1,
        strokeColor: "#000",
        strokeWeight: 1.5,
      },
    });

    // Dropoff marker
    new google.maps.Marker({
      position: {
        lat: ride.dropoff.lat,
        lng: ride.dropoff.lng,
      },
      map,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 7,
        fillColor: "#D50000",
        fillOpacity: 1,
        strokeColor: "#000",
        strokeWeight: 1.5,
      },
    });
  }, [ride]);

  // ─────────────────────────────────────────────
  // Status-driven map behavior
  // ─────────────────────────────────────────────
  useEffect(() => {
    if (!ride || !mapInstanceRef.current || !window.google?.maps) return;

    const map = mapInstanceRef.current;

    // Clear previous route
    if (routeRendererRef.current) {
      routeRendererRef.current.setMap(null);
      routeRendererRef.current = null;
    }

    // DRIVER_ASSIGNED or ON_TRIP → show route
    if (
      (ride.status === "DRIVER_ASSIGNED" || ride.status === "ON_TRIP") &&
      ride.driver?.lat &&
      ride.driver?.lng
    ) {
      const directionsService = new google.maps.DirectionsService();
      const directionsRenderer = new google.maps.DirectionsRenderer({
        suppressMarkers: true,
        polylineOptions: {
          strokeColor: "#103139",
          strokeWeight: 5,
        },
      });

      directionsRenderer.setMap(map);
      routeRendererRef.current = directionsRenderer;

      const origin =
        ride.status === "DRIVER_ASSIGNED"
          ? { lat: ride.driver.lat, lng: ride.driver.lng }
          : { lat: ride.driver.lat, lng: ride.driver.lng };

      const destination =
        ride.status === "DRIVER_ASSIGNED"
          ? { lat: ride.pickup.lat, lng: ride.pickup.lng }
          : { lat: ride.dropoff.lat, lng: ride.dropoff.lng };

      directionsService.route(
        {
          origin,
          destination,
          travelMode: google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === "OK") {
            directionsRenderer.setDirections(result);
          }
        }
      );
    }

    // Driver marker (static position updates only)
    if (ride.driver?.lat && ride.driver?.lng) {
      const driverLatLng = {
        lat: ride.driver.lat,
        lng: ride.driver.lng,
      };

      if (!driverMarkerRef.current) {
        driverMarkerRef.current = new google.maps.Marker({
          position: driverLatLng,
          map,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 6,
            fillColor: "#00C853",
            fillOpacity: 1,
            strokeColor: "#000",
            strokeWeight: 2,
          },
        });
      } else {
        driverMarkerRef.current.setPosition(driverLatLng);
      }

      map.panTo(driverLatLng);
    }
  }, [ride]);

  if (!ride) {
    return (
      <div className="flex items-center justify-center min-h-[70vh]">
        <div className="w-12 h-12 border-4 border-townwize-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div
        ref={mapRef}
        className="w-full h-96 rounded-xl shadow border border-gray-300 dark:border-gray-700"
      />

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow space-y-2">
        <p className="text-sm">
          <strong>Status:</strong> {ride.status}
        </p>
        <p className="text-sm">
          <strong>Pickup:</strong> {ride.pickup.address}
        </p>
        <p className="text-sm">
          <strong>Dropoff:</strong> {ride.dropoff.address}
        </p>
        <p className="text-sm">
          <strong>Fare:</strong> {ride.fareEstimate} PKR
        </p>
      </div>
    </div>
  );
};

export default LiveTracking;
